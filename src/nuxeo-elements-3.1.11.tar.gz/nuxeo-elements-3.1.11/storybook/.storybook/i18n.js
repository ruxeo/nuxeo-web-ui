import messages from '../../ui/i18n/messages.json';

window.nuxeo = {
  I18n: {
    language: 'en',
    en: messages,
  },
};
