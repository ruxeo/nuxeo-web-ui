export const TARGET = ['_blank', '_self', '_parent', '_top'];
