# About nuxeo-document-permissions

**Nuxeo Document Permissions** is an element for managing document permissions in Nuxeo.
