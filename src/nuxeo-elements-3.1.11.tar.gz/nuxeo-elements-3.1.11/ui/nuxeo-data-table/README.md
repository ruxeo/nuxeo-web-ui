# About nuxeo-data-table

**Nuxeo data table** is derived from the [Saulis iron-data-table](https://github.com/Saulis/iron-data-table).

It has been adapted to provide infinite scrolling on data retrieved from a [nuxeo-page-provider](https://github.com/nuxeo/nuxeo-elements/blob/master/nuxeo-page-provider.html) element passed as a parameter.

Column filtering and sorting is also plugged to the [nuxeo-page-provider](https://github.com/nuxeo/nuxeo-elements/blob/master/nuxeo-page-provider.html)'s parameters and sorting feature.
