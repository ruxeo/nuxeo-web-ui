module.exports = Object.assign(require('@open-wc/prettier-config'), {
  printWidth: 120,
  arrowParens: 'always',
});
