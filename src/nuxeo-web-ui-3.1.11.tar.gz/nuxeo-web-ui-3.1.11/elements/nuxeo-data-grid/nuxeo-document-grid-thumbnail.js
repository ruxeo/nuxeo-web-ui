/**
@license
©2023 Hyland Software, Inc. and its affiliates. All rights reserved. 
All Hyland product names are registered or unregistered trademarks of Hyland Software, Inc. or its affiliates.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
*/
import '@polymer/polymer/polymer-legacy.js';

import '@polymer/paper-icon-button/paper-icon-button.js';
import { FormatBehavior } from '@nuxeo/nuxeo-ui-elements/nuxeo-format-behavior.js';
import { RoutingBehavior } from '@nuxeo/nuxeo-ui-elements/nuxeo-routing-behavior.js';
import '@nuxeo/nuxeo-ui-elements/actions/nuxeo-download-button.js';
import '@nuxeo/nuxeo-ui-elements/actions/nuxeo-favorites-toggle-button.js';
import '@nuxeo/nuxeo-ui-elements/widgets/nuxeo-tag.js';
import '@nuxeo/nuxeo-ui-elements/widgets/nuxeo-tooltip';
import { Polymer } from '@polymer/polymer/lib/legacy/polymer-fn.js';
import { html } from '@polymer/polymer/lib/utils/html-tag.js';

/**
`nuxeo-document-grid-thumbnail`
@group Nuxeo UI
@element nuxeo-document-grid-thumbnail
*/
Polymer({
  _template: html`
    <style>
      :host {
        outline: none;
        -webkit-touch-callout: none;
        -webkit-user-select: none;
        -moz-user-select: none;
        -ms-user-select: none;
        user-select: none;
        cursor: pointer;
      }

      a {
        @apply --nuxeo-link;
      }

      .bubbleBox {
        display: block;
        margin: 0 0.4em 0.8em;
        position: relative;
        width: 220px;
        height: 260px;
        background-color: var(--nuxeo-box);
        box-shadow: 0 3px 5px rgba(0, 0, 0, 0.04);
        padding: 0;
        filter: 0.1s ease-out, filter 0.1s ease-out;
        -webkit-filter: 0.1s ease-out, filter 0.1s ease-out;
        border: 2px solid transparent;
      }

      .bubbleBox:hover {
        z-index: 500;
        border: 2px solid var(--nuxeo-link-hover-color);
        box-shadow: 0 3px 5px rgba(0, 0, 0, 0.04);
      }

      .bubbleBox .title {
        margin-bottom: 0.4em;
      }

      .bubbleBox:hover .title {
        color: var(--nuxeo-link-hover-color);
      }

      .thumbnailContainer {
        background-color: rgba(0, 0, 0, 0.1);
        width: 100%;
        height: 190px;
        position: relative;
      }

      .thumbnailContainer img {
        height: auto;
        width: auto;
        max-height: 100%;
        max-width: 100%;
        position: absolute;
        top: 0;
        bottom: 0;
        left: 0;
        right: 0;
        margin: auto;
      }

      .dataContainer {
        padding: 0.3em 0.8em;
      }

      .dataContainer p {
        margin: 0 0 0.4em;
        font-size: 0.75rem;
      }

      .bubbleBox .select {
        position: absolute;
        top: 1rem;
        left: 1rem;
        border: 2px solid #ddd;
        background-color: var(--nuxeo-box);
        z-index: 2;
        border-radius: 3em;
      }

      .select paper-icon-button {
        margin: 0;
        padding: 0.3em;
        box-sizing: border-box;
      }

      .bubbleBox .select,
      .select paper-icon-button {
        width: 2.5em;
        height: 2.5em;
      }

      .select:hover paper-icon-button {
        color: #fff;
      }

      .title {
        text-overflow: ellipsis;
        overflow: hidden;
        white-space: nowrap;
        display: block;
      }

      .bubbleBox .actions {
        background-color: var(--nuxeo-box);
        position: absolute;
        bottom: 0;
        left: 0;
        right: 0;
        min-height: 2.5em;
      }

      .actions paper-icon-button iron-icon {
        @apply --nuxeo-action;
      }

      .actions paper-icon-button:hover iron-icon {
        @apply --nuxeo-action-hover;
      }

      .bubbleBox:hover .select:hover {
        border: 2px solid var(--nuxeo-button-primary);
        background-color: var(--nuxeo-button-primary);
      }

      :host([selected]) .bubbleBox .select,
      :host([selected]) .bubbleBox:hover .select:hover {
        border: 2px solid var(--nuxeo-grid-selected);
        background-color: var(--nuxeo-grid-selected);
        display: block;
      }

      :host([selected]) .select paper-icon-button {
        color: #fff;
      }

      :host([selected]) .bubbleBox {
        border: 2px solid var(--nuxeo-grid-selected);
        box-shadow: 0 3px 5px rgba(0, 0, 0, 0.04);
      }

      :host(.droptarget-hover) .bubbleBox {
        border: 2px dashed var(--nuxeo-grid-selected);
      }

      :host(:focus) .bubbleBox {
        z-index: 500;
        border: 2px solid var(--nuxeo-link-hover-color);
        box-shadow: 0 3px 5px rgba(0, 0, 0, 0.04);
      }

      :host(:focus) .bubbleBox .actions,
      :host(:focus) .bubbleBox .select,
      .bubbleBox:hover .actions,
      .bubbleBox:hover .select,
      .bubbleBox[selection-mode] .select {
        opacity: 1;
        height: auto;
        overflow: visible;
        transition: opacity 0.2s ease, height 0.2s ease;
      }

      .bubbleBox .actions,
      .bubbleBox .select {
        opacity: 0;
        height: 0;
        overflow: hidden;
        transition: opacity 0.2s ease, height 0.2s ease;
      }
    </style>

    <div class="bubbleBox grid-box" selection-mode$="[[selectionMode]]">
      <div class="thumbnailContainer" on-tap="handleClick" tabindex="0">
        <img src="[[_thumbnail(doc)]]" alt$="[[doc.title]]" />
      </div>
      <template is="dom-if" if="[[_hasDocument(doc)]]">
        <a class="title" href$="[[urlFor(doc)]]" on-tap="handleClick" tabindex="0">
          <div class="dataContainer">
            <div class="title" id="title">[[doc.title]]</div>
            <nuxeo-tag>[[formatDocType(doc.type)]]</nuxeo-tag>
            <nuxeo-tooltip for="title">[[doc.title]]</nuxeo-tooltip>
          </div>
        </a>
        <div class="actions">
          <nuxeo-favorites-toggle-button document="[[doc]]"></nuxeo-favorites-toggle-button>
          <nuxeo-download-button document="[[doc]]"></nuxeo-download-button>
        </div>
        <div class="select">
          <paper-icon-button
            noink
            icon="icons:check"
            title="[[_computeTitle(doc)]]"
            on-tap="_onCheckBoxTap"
            on-keydown="_onCheckBoxTap"
            role="checkbox"
            aria-checked="[[selected]]"
          ></paper-icon-button>
        </div>
      </template>
    </div>
  `,

  is: 'nuxeo-document-grid-thumbnail',
  behaviors: [FormatBehavior, RoutingBehavior],

  properties: {
    doc: {
      type: Object,
      notify: true,
    },

    offset: {
      type: Number,
      value: -1,
    },

    selected: {
      type: Boolean,
      value: false,
      reflectToAttribute: true,
    },

    selectedItems: {
      type: Array,
      value: [],
    },

    index: {
      type: Number,
    },
  },

  observers: ['_selectedItemsChanged(selectedItems.splices)'],

  _thumbnail(doc) {
    if (
      doc &&
      doc.uid &&
      doc.contextParameters &&
      doc.contextParameters.thumbnail &&
      doc.contextParameters.thumbnail.url
    ) {
      if (!this.isFollowRedirectEnabled()) {
        const splitter = doc.contextParameters.thumbnail.url.indexOf('?') > -1 ? '&' : '?';
        doc.contextParameters.thumbnail.url = `${doc.contextParameters.thumbnail.url}${splitter}clientReason=view`;
      }
      return doc.contextParameters.thumbnail.url;
    }
    return '';
  },

  isFollowRedirectEnabled() {
    const followRedirect =
      Nuxeo && Nuxeo.UI && Nuxeo.UI.config && Nuxeo.UI.config.url && Nuxeo.UI.config.url.followRedirect;
    return followRedirect ? String(followRedirect).toLowerCase() === 'true' : false;
  },

  handleClick(e) {
    if (this.selectionMode) {
      this._toogleSelect(e);
    } else if (!(e.ctrlKey || e.shiftKey || e.metaKey || e.button === 1)) {
      this.fire('navigate', { item: this.doc, index: this.index });
    }
  },

  _onCheckBoxTap(e) {
    // WEBUI-1262 : prevents checkbox selection during tab navigation
    if (e.type === 'tap' || (e.key !== 'Tab' && e.key !== 'Shift')) {
      this._toogleSelect(e);
    }
  },

  _toogleSelect(e) {
    this.selected = !this.selected;
    this.fire('selected', { index: this.index, shiftKey: e.type === 'tap' ? e.detail.sourceEvent.shiftKey : false });
  },

  _selectedItemsChanged() {
    this.selectionMode = this.selectedItems && this.selectedItems.length > 0;
  },

  _hasDocument() {
    return this.doc && this.doc.uid;
  },

  _computeTitle(doc) {
    return `${doc && doc.title}${this.i18n && this.i18n('command.select')}`;
  },
});
