All images, icons, fonts, and videos contained in this folder are copyrighted by Hyland Software, all rights reserved.
