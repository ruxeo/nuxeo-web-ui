fixtures.blobs = {
  get: (file) => `resources/${file}`,
};
