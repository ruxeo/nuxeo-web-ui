import moment from 'moment';

global.moment = moment;
global.dateFormat = 'LL';
