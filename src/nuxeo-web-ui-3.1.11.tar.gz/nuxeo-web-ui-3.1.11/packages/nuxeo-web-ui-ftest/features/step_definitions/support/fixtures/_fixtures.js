// global.fixtures = {};
