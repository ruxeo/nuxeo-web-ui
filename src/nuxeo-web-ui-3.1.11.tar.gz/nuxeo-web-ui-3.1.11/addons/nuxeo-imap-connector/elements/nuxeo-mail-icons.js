/*
©2023 Hyland Software, Inc. and its affiliates. All rights reserved. 
All Hyland product names are registered or unregistered trademarks of Hyland Software, Inc. or its affiliates.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
*/
import '@polymer/iron-iconset-svg/iron-iconset-svg.js';
import { html } from '@polymer/polymer/lib/utils/html-tag.js';

const template = html`
  <iron-iconset-svg size="24" name="nuxeo-mail">
    <svg>
      <defs>
        <g id="sync">
          <path
            d="M11.875 11.01l4.293-2.572a1.969 1.969 0 0 0-1.324-.518H8.906c-.511 0-.973.2-1.324.518l4.293 2.572z"
          ></path>
          <path
            d="M12.257 12.512a.744.744 0 0 1-.764 0l-4.554-2.73c-.002.039-.012.076-.012.116v3.954c0 1.092.887 1.978 1.98 1.978h5.937c1.092 0 1.979-.886 1.979-1.978V9.898c0-.04-.01-.077-.012-.117l-4.554 2.73z"
          ></path>
          <path
            d="M20.552 13.977c-.904 3.957-4.448 6.92-8.677 6.92-4.013 0-7.411-2.665-8.521-6.316L5.937 12H0v5.932l1.808-1.806c1.63 3.955 5.527 6.749 10.067 6.749 5.326 0 9.762-3.844 10.696-8.898h-2.02zM22.013 7.75C20.383 3.794 16.487 1 11.946 1 6.62 1 2.184 4.844 1.25 9.898h2.02c.903-3.957 4.447-6.92 8.676-6.92 4.013 0 7.411 2.665 8.522 6.317l-2.584 2.58h5.937V5.943L22.013 7.75z"
          ></path>
        </g>
      </defs>
    </svg>
  </iron-iconset-svg>
`;

document.head.appendChild(template.content);
