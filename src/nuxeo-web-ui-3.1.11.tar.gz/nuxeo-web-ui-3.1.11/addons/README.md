Addons Web UI extension are located in this directory
